
public class soma
{
    public static void main(String[]args)
    {
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        int c = a + b; // realiza a soma
        System.out.println(“O Resultado da soma é: ” + c);
    }
}
