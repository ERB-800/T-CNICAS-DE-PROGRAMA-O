
/**
 * Escreva uma descrição da classe repeticaowhile aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class RepeticaoWhile
{
public static void main(String arg)
{
int i = 1;// inicialização de i
while (i <= 10)
{ // encerramento em 10
System.out.println("i = " + i + " / Parâmetro: "+ arg); // imprime o valor da variavel i;
i++; // iteracao para adicionar 1 em i
}
}
}