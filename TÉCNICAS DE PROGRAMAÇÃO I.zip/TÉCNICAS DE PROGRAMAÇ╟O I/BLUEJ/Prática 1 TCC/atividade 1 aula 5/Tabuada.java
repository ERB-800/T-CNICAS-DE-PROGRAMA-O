
public class Tabuada
{
    public static void main (String[]args)
    {
        int numero = Integer.parseInt(args[0]);
        int i = 0;
        
        
        System.out.println("Tabuada do " + numero + ":");
        for (int arg = 1; i <= 10; i++) {
            int resultado = numero * i;
            System.out.println(i + "x" + numero + " = " + resultado);
        }
    }
}