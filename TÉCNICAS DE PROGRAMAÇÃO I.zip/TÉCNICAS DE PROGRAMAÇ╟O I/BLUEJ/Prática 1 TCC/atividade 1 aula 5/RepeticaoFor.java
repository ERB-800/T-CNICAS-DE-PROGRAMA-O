
/**
 * Escreva uma descrição da classe Repeticaofor aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class RepeticaoFor
{
public static void main(String arg)
{
for (int i = 1; i <= 10; i++) // repete 10 vezes
System.out.println("i = " + i + " / Parâmetro: "+ arg); }
}