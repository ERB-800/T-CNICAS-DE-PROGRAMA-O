
/**
 * Escreva uma descrição da classe Coordenador aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Coordenador
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private int ramal1, ramal2, ramal3; 
    private String carga_horaria_seg_e_qua, carga_horaria_ter_e_qui, carga_horaria_sex_e_sab;
    

    /**
     * Construtor para objetos da classe Coordenador
     */
    public Coordenador(int ramal1, int ramal2, int ramal3, String carga_horaria_seg_e_qua, String carga_horaria_ter_e_qui, String carga_horaria_sex_e_sab)
    {
        // inicializa variáveis de instância
        this.ramal1 = ramal1;
        this.ramal2 = ramal2;
        this.ramal3 = ramal3;
        this.carga_horaria_seg_e_qua = carga_horaria_seg_e_qua;
        this.carga_horaria_ter_e_qui = carga_horaria_ter_e_qui;
        this.carga_horaria_sex_e_sab = carga_horaria_sex_e_sab;
    }

    /**
     * Um exemplo de um método - substitua este comentário pelo seu próprio
     * 
     * @param  y   um exemplo de um parâmetro de método
     * @return     a soma de x e y 
     */
    public void exibeInformacoes( )
    {
        // escreva seu código aqui
        System.out.println("Informações do coordenador: ");
        System.out.println("ramal1: "+ramal1);
        System.out.println("ramal2: "+ramal2);
        System.out.println("ramal3: "+ramal3);
        System.out.println("carga_horaria: "+carga_horaria_seg_e_qua);
        System.out.println("carga_horaria: "+carga_horaria_ter_e_qui);
        System.out.println("carga_horaria: "+carga_horaria_sex_e_sab);
    }
}
