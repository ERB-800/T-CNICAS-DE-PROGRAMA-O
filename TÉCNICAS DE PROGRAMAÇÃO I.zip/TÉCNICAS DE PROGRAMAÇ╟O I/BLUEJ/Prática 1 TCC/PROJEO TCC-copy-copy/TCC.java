
/**
 * Escreva uma descrição da classe TCC aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class TCC
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String titulo, situacao;
    private int ano, notas1, notas2, notas3;

    /**
     * Construtor para objetos da classe TCC
     */
    public TCC(String titulo, String situacao, int ano, int notas1, int notas2,
    int notas3)
    {
        // inicializa variáveis de instância
        this.titulo = titulo;
        this. situacao = situacao;
        this.ano = ano;
        this.notas1 = notas1;
        this.notas2 = notas2;
        this.notas3 = notas3;
    }

    /**
     * Um exemplo de um método - substitua este comentário pelo seu próprio
     * 
     * @param  y   um exemplo de um parâmetro de método
     * @return     a soma de x e y 
     */
    public void exibeInformacoes( )
    {
        // escreva seu código aqui
        System.out.println("Informações do TCC: ");
        System.out.println("titulo: " +titulo);
        System.out.println("situacao: "+situacao);
        System.out.println("Ano: "+ano);
        System.out.println("Nota 1: "+notas1);
        System.out.println("Nota 2: "+notas2);
        System.out.println("Nota 3: "+notas3);
    }
}
