
/**
 * Escreva uma descrição da classe Banca aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Banca
{
    // variáveis de instância - substitua o exemplo abaixo pelo seu próprio
    private String data; 
    private String parecer;

    /**
     * Construtor para objetos da classe Banca
     */
    public Banca(String data, String parecer)
    {
        // inicializa variáveis de instância
    this.data = data;
    this.parecer = parecer;
    }

    /**
     * Um exemplo de um método - substitua este comentário pelo seu próprio
     * 
     * @param  y   um exemplo de um parâmetro de método
     * @return     a soma de x e y 
     */
    public void exibeInformacoes( )
    {
        // escreva seu código aqui
        System.out.println("Esta banca possui: ");
        System.out.println("data: "+data);
        System.out.println("parecer: "+parecer);
    }
}
