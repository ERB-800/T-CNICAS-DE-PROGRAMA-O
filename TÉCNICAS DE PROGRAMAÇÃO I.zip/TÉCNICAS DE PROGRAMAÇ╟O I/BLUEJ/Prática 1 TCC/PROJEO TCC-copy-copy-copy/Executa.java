public class Executa
{
    public static void main (String arg)
    {
        System.out.println("Você passou o parâmetro: " +arg);
    }
}