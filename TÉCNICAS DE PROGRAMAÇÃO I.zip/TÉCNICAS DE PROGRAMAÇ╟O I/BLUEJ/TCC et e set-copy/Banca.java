/**
 * Classe Banca.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Banca{
 // variáveis da instância que representam as características da Banca
 private String data;
 private String parecer;
 /**
 * Método Construtor responsável por criar objetos do tipo Banca
 */
 public Banca(String data, String parecer){
 // atribui valores para as variáveis da instância (objeto)
 this.data = data;
 this.parecer = parecer;
 }
 /**
 * Método que exibe informações sobre a Banca
 */
 public void exibeInformacoes( ){
 System.out.println("Informações sobre a Banca:");
 System.out.println("Data: "+data);
 System.out.println("Parecer: "+parecer);
 }
}