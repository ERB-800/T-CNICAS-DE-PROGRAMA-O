package biblioteca;

public class Aluno extends Pessoa {
    private String rg;
    private String curso;

    public Aluno(String nome, String dataNascimento, String rg, String curso) {
        super(nome, dataNascimento); // Chama o construtor da classe Pessoa
        this.rg = rg;
        this.curso = curso;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
}