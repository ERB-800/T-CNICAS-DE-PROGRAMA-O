package biblioteca;

import java.util.ArrayList;
import java.util.List;

public class Pessoa {
    private String nome;
    private String dataDeNascimento;
    private List<Livro> livrosPossuidos; // Lista de livros associados à pessoa

    public Pessoa(String nome, String data) {
        this.nome = nome;
        dataDeNascimento = data;
        livrosPossuidos = new ArrayList<>(); // Inicializa a lista de livros
    }

    // Métodos para adicionar e remover livros da lista
    public void adicionarLivro(Livro livro) {
        livrosPossuidos.add(livro);
    }

    public void removerLivro(Livro livro) {
        livrosPossuidos.remove(livro);
    }

    public List<Livro> getLivrosPossuidos() {
        return livrosPossuidos;
    }

    // Outros métodos e getters/setters conforme necessário
}