/**
 * Classe Coordenador.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Coordenador
{
 // variáveis da instância que representam as características do Coordenador
 private String ramal;
 private String cargaHoraria;
 /**
 * Método Construtor responsável por criar objetos do tipo Coordenador
 */
 public Coordenador(String ramal, String cargaHoraria)
 {
 // atribui valores para as variáveis da instância (objeto)
 this.ramal = ramal;
 this.cargaHoraria = cargaHoraria;
 }
 /**
 * Método que exibe informações sobre o Coordenador
 */
 public void exibeInformacoes( )
 {
 System.out.println("Informações sobre Coordenador:");
 System.out.println("Ramal: "+ramal);
 System.out.println("Carga Horária: "+cargaHoraria);
 }
}