/**
 * Classe Tcc.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tcc{
 // variáveis da instância que representam as características do Tcc
 private String titulo;
 private int ano;
 private String situacao;
 private float nota;
 /**
 * Método Construtor responsável por criar objetos do tipo Tcc
 */
 public Tcc(String titulo, int ano, String situacao, float nota){
 // atribui valores para as variáveis da instância (objeto)
 this.titulo = titulo;
 this.ano = ano;
 this.situacao = situacao;
 this.nota = nota;
 }
 /**
 * Método que exibe informações sobre o Tcc
 */
 public void exibeInformacoes( ){
 System.out.println("Informações sobre Tcc:");
 System.out.println("Título: "+titulo);
 System.out.println("Ano: "+ano);
 System.out.println("Situação: "+situacao);
 System.out.println("Nota: "+nota);
 }
}