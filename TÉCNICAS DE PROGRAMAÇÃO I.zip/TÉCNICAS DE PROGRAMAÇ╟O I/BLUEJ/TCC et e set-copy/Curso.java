 /**
 * Classe Curso.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Curso
{
 // variáveis da instância que representam as características do Curso
 private String nome;
 private String sigla;
 private String area;
 /**
 * Método Construtor responsável por criar objetos do tipo Curso
 */
 public Curso(String nome, String sigla, String area){
 // atribui valores para as variáveis da instância (objeto)
 this.nome = nome;
 this.sigla = sigla;
 this.area = area;
 }
 /**
 * Método que exibe informações sobre o Curso
 */
 public void exibeInformacoes( ){
 System.out.println("Informações sobre Curso:");
 System.out.println("Nome: "+nome);
 System.out.println("Sigla: "+sigla);
 System.out.println("Área: "+area);
 }
}