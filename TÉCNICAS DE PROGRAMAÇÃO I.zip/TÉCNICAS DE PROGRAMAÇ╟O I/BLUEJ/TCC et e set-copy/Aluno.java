/**
 * Classe Aluno.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Aluno
{
 // variáveis da instância que representam as características do Aluno
 private String nome;
 private String ra;
 /**
 * Método Construtor responsável por criar objetos do tipo Aluno
 */
 public Aluno(String nome, String ra)
 {
 // atribui valores para as variáveis da instância (objeto)
 this.nome = nome;
 this.ra = ra;
 }
 /**
 * Método que exibe informações sobre o Aluno
 */
 public void exibeInformacoes( )
 {
 System.out.println("Informações sobre Aluno:");
 System.out.println("Nome: "+nome);
 System.out.println("Ra: "+ra);
 }
}