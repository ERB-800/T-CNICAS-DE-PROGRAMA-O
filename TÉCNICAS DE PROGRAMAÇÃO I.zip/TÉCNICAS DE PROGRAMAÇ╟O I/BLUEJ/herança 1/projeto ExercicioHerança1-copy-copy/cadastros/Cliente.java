package cadastros;

public class Cliente extends Pessoa {
    private int numeroCliente;

    public Cliente(String nome, int idade, int numeroCliente) {
        
       
super(nome, idade);
        this.numeroCliente = numeroCliente;
    }

    public int getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(int numeroCliente) {
        this.numeroCliente = numeroCliente;
    }
}